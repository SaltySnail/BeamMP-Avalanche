local loadHomeDelay = 30
local secondsPassed = 0
local running = false

--A chat message was sent
--The sender's ID, the sender's name, and the chat message
function onChatMessage(player_id, player_name, message)
	print("chatMessage: " .. message)
	if string.find(message, "/avalanche ") then
		message = string.gsub(message, "/avalanche ", "")
		print(message)
		if string.find(message, "start %d") then
			print("found start")
			loadHomeDelay = tonumber(string.sub(message,7,10000))
			running = true
		elseif string.find(message, "delay %d") then
			loadHomeDelay = tonumber(string.sub(message,7,10000))
		elseif string.find(message, "name %s") then
			local carName = string.sub(message,6,10000)
			print("Name: " .. carName)
			MP.TriggerClientEvent(-1, "AVsetJbeamNameTry2", carName)
		elseif string.find(message, "stop") then
			running = false
		end
		return 1
	end
end

function avalancheTimer()
	if not running then return end
	secondsPassed = secondsPassed + 0.5
	if secondsPassed < loadHomeDelay then return end
	secondsPassed = 0
	print("Triggering AVloadHomes")
	MP.TriggerClientEvent(-1, "AVloadHomes", "nil")
end

function onInit() 
	MP.RegisterEvent("onChatMessage", "onChatMessage")

	MP.CancelEventTimer("counter")
	MP.CancelEventTimer("avalancheTrigger")
	MP.CreateEventTimer("avalancheTrigger", 500)
	MP.RegisterEvent("avalancheTrigger", "avalancheTimer")
	
	print("--------------------Avalanche loaded------------------------")

end
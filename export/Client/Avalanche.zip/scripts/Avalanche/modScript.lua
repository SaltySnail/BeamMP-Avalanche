load('Avalanche')
setExtensionUnloadMode('Avalanche', 'manual')
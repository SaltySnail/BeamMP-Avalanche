local M = {} --metatable

local jbeamName = "Puck"

function AVloadHomes()
	print(jbeamName .. dump(getOwnMap()))
	for ID, veh in pairs(getOwnMap()) do 
		if veh["jbeam"] == jbeamName then
			be:getObjectByID(ID):queueLuaCommand("recovery.loadHome()")
		end
	end
end

function AVsetJbeamName(name)
	print("AVsetJbeamName: " .. name)
	jbeamName = name
end

if MPGameNetwork then AddEventHandler("AVloadHomes", AVloadHomes) end
if MPGameNetwork then AddEventHandler("AVsetJbeamName", AVsetJbeamName) end

M.AVloadHomes = AVloadHomes
M.AVsetJbeamName = AVsetJbeamName

return M --return the metatable	